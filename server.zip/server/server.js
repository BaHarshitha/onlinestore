const express = require("express");
const app = express();

require('dotenv').config();
const bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
const morgan = require('morgan');

const cors = require('cors');

// Allow Cross Origin Requests
app.use(cors());

// Database connection
require('./Utils/database')();

app.use(morgan(':date[clf]] ":url" :status :response-time ms --', {
}));
  

// Redirect to API's
app.use('/', require('./Routes/orders'));

// Start the server
const port = process.env.PORT || 4000;
app.listen(port, () => {
  console.log("Server started on port " + port);
});