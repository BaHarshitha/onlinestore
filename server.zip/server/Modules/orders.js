const mongoose = require('mongoose')

const orderSchema = mongoose.Schema({
    "order_id":{
        type:Number,
        required:true,
        unique:true
    },
    "datetime":{
        type:Date
    },
    "totalfee":{
        type:Number,
        required:true
    },
    "service_record":[{
        "service_id":{
            type:Number,
            required:true
        },
        "name":{
            type:String,
            required:true
        }
    }]
},{strict:true})

module.exports=mongoose.model("Orders",orderSchema)