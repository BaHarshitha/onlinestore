const mongoose = require("mongoose");

// MongoDB Connection
const connectDB = async () => {
    try {
        const connection = await mongoose.connect(process.env.Mongo_URL);
        console.log(`Successfully connected to database: ${connection.connections[0].name}`);
    } catch (error) {
        console.log("Error while connecting to DB", error);
    }
}

module.exports = connectDB;
