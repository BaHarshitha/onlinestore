const express = require('express')
const orderRoute =  express.Router()
const orderCntrl = require('../Controllers/orders')

orderRoute.post('/order', orderCntrl.createOrder)
orderRoute.get('/orders', orderCntrl.getOrders)
orderRoute.get('/order', orderCntrl.getOrdersbyId)
orderRoute.put('/order', orderCntrl.updateOrder)
orderRoute.delete('/order', orderCntrl.deleteOrder)


module.exports = orderRoute;