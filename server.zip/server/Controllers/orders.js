const Order = require("../Modules/orders")

// create order
const createOrder = async (req, res) => {
    try {
      const orderExists = await Order.exists({ order_id: req.body.order_id });
  
      if (orderExists) {
        res.status(400).json({ error: "Order with the same order_id already exists" });
      }
      else{
        const newOrder = new Order({
            order_id: req.body.order_id,
            datetime: new Date(),
            totalfee: req.body.totalfee,
            service_record: [
              {
                service_id: req.body.service_id,
                name: req.body.service_name
              }
            ]
          });
      
          await newOrder.save();
          res.status(201).json({ message: "Order placed successfully" });
      }

    } catch (error) {
      console.error(error);
      res.status(500).json({ error: "Error while placing the order" });
    }
  };
  

// get orders
const getOrders = async (req,res) =>{
    try {
        const orders = await Order.find().select({"order_id":1,"datetime":1,"server_id":1,"totalfee":1,"_id":0})
        if (orders){
            res.status(200).json({data:orders})
        }
        else{
            res.status(402).json({message:"No data"})
        }
        
    } catch (error) {
        res.status(500).json({error:"Error while fetching the order"})
    }
}

// get order by Id
const getOrdersbyId = async (req, res) => {
    try {
      const orderId = req.query.order_id;
      const order = await Order.findOne({order_id:orderId});
  
      if (!order) {
        res.status(404).json({ error: "Order not found" });
      }
      else{
        res.status(200).json({data:order});
      }
    } catch (error) {
      res.status(500).json({ error: "Error while fetching the order" });
    }
  };


 // Update the order details
const updateOrder = async (req, res) => {
    try {
      const orderId = req.body.order_id;

      const orderToUpdate = await Order.findOne({order_id:orderId});
  
      if (!orderToUpdate) {
        res.status(404).json({ error: "Order not found" });
      }
      
      const orderDatetime = orderToUpdate.datetime;
      const currentTime = new Date();
      const timeDifferenceInHours = Math.abs(currentTime - orderDatetime) / 36e5;
  
      // Check if the order datetime is within 3 hours from now
      if (timeDifferenceInHours > 3) {
        return res.status(400).json({ error: "Cannot update order after 3 hours" });
      }
      
      orderToUpdate.totalfee = req.body.totalfee;
      await orderToUpdate.save();
      res.status(200).json({ message: "Order updated successfully" });
    } catch (error) {
      res.status(500).json({ error: "Error while updating the order" });
    }
  };

// Delete the order
const deleteOrder = async (req, res) => {
    try {
      const orderId = req.body.order_id;

      const orderToDelete = await Order.findOne({order_id:orderId});
  
      if (!orderToDelete) {
        res.status(404).json({ error: "Order not found" });
      }
  
      const orderDatetime = orderToDelete.datetime;
      const currentTime = new Date();
      const timeDifferenceInHours = Math.abs(currentTime - orderDatetime) / 36e5;
  
      // Check if the order datetime is within 3 hours from now
      if (timeDifferenceInHours > 3) {
        return res.status(400).json({ error: "Cannot delete order after 3 hours" });
      }

      await Order.deleteOne({order_id:orderId});
  
      res.status(200).json({ message: "Order deleted successfully" });
    } catch (error) {
      res.status(500).json({ error: "Error while deleting the order" });
    }
  };


module.exports = {
    createOrder,
    getOrders,
    updateOrder,
    deleteOrder,
    getOrdersbyId,
}